import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowquestionComponent } from './showquestion.component';

describe('ShowquestionComponent', () => {
  let component: ShowquestionComponent;
  let fixture: ComponentFixture<ShowquestionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowquestionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowquestionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
