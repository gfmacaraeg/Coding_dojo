from django.shortcuts import render, redirect
from .models import League, Team, Player

from . import team_maker

def index(request):
	context = {
		# "leagues": League.objects.all(),
		# ...all baseball leagues
		# "leagues": League.objects.filter(sport="Baseball"),
		# ...all womens' leagues
		# "leagues": League.objects.filter(name__contains="Women"),
		# ...all leagues where sport is any type of hockey
		# "leagues": League.objects.filter(sport__contains="Hockey"),
		# ...all leagues where sport is something OTHER THAN football
		# "leagues": League.objects.exclude(sport ="Football"),
		# ...all leagues that call themselves "conferences"
		# "leagues": League.objects.filter(name__contains ="Conference"),
		# all leagues in the Atlantic region
		"leagues": League.objects.filter(name__contains ="Conference"),
		"teams": Team.objects.all(),
		"players": Player.objects.all(),
	}
	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")