from __future__ import unicode_literals

from django.apps import AppConfig


class NewAppConfig(AppConfig):
    name = 'new_app'
