# Write a program that would print all the odd numbers from 1 to 255.
# puts (1..255).reject { |i|  i.even? }

# Write a program that would print the numbers from 0 to 255 
# but this time, it would also print the sum of the numbers that have been printed so far. 
# For example, your output should be something like this:
# New number: 0 Sum: 0
# sum = 0
# (1...255).find_all { |i|  puts "New number: #{i} Sum: #{sum += i}"}

# Write a program that takes an array, and prints the AVERAGE of the values in the array. 
# arr = [2, 10, 3]
# sum = 0
# arr.each { |a| sum+=a }
# puts sum/arr.length

# Write a program that creates an array 'y' that contains all the odd numbers between 1 to 255.

# print (1..255).find_all { |i| i % 3 == 0}

# Write a program that takes an array and returns the number of values in that array whose value is greater than a given value y. 
# print ([1, 5, 10, -2].find_all {|i| i > 3}).length

# Given any array x, say [1, 5, 10, -2], create an algorithm (sets of instructions) that multiplies each value in the array by itself.

 # [1, 5, 10, -2].each {|i| puts i*i }

 # Eliminate Negative Numbers
  # print [1, 5, 10, -2].map { |i| i < 0? 0 : i}

  # Max, Min, and Average
# arr = [1, 5, 10, -2]
# arr.rotate!(1)[arr.length-1] = 0
# print arr

# Number to String
arr = [-1, -3, 2]
print arr.each_index { |index| arr[index] = "Dojo" if arr[index] < 0 }