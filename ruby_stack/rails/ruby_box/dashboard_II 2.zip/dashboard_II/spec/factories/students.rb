FactoryGirl.define do
  factory :student do
    first_name "MyString"
    last_name "MyString"
    email "MyString"
    dojo nil
  end
end
