FactoryGirl.define do
  factory :bright_idea do
    content "MyString"
    user nil
  end
end
