FactoryGirl.define do
  factory :like do
    user nil
    bright_idea nil
  end
end
