FactoryGirl.define do
  factory :dojo do
    branch "MyString"
    street "MyString"
    city "MyString"
    state "MyString"
  end
end
